							<div class="copy">
								<p><?php echo SITE_COPY_RIGHTS; ?> </p>
							</div>
						</div>
					</div>
					<div class="clearfix"> </div>
				</div>
				<script src="js/jquery.nicescroll.js"></script>
				<script src="js/scripts.js"></script>
			</body>
		</html>