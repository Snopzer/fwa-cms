-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 01, 2016 at 07:45 AM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fwa-cms`
--

-- --------------------------------------------------------

--
-- Table structure for table `r_category`
--

CREATE TABLE `r_category` (
  `id_category` int(11) NOT NULL,
  `name` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `description` text COLLATE latin1_general_ci,
  `image` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `meta_title` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `meta_keywords` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `meta_description` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `sort_order` int(11) NOT NULL,
  `status` int(1) DEFAULT NULL COMMENT '1:Enable;0:Disble',
  `date_created` datetime NOT NULL,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `r_comment`
--

CREATE TABLE `r_comment` (
  `id_comment` int(11) NOT NULL,
  `name` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `email` varchar(99) COLLATE latin1_general_ci DEFAULT NULL,
  `subject` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `message` text COLLATE latin1_general_ci,
  `post_id` int(10) NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `r_country`
--

CREATE TABLE `r_country` (
  `id_country` int(11) NOT NULL,
  `name` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL COMMENT '1:Enable; 0:Disable'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `r_image`
--

CREATE TABLE `r_image` (
  `id_image` int(11) NOT NULL,
  `image_name` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `image` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `status` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `r_message`
--

CREATE TABLE `r_message` (
  `id_message` int(11) NOT NULL,
  `name` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `subject` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `email` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `message` text COLLATE latin1_general_ci,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date_updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `status` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `r_page`
--

CREATE TABLE `r_page` (
  `id_page` int(11) NOT NULL,
  `title` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `meta_description` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `meta_keywords` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `page_heading` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `page_description` text COLLATE latin1_general_ci,
  `status` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `r_post`
--

CREATE TABLE `r_post` (
  `id_post` int(11) NOT NULL,
  `status` int(1) NOT NULL,
  `id_category` int(11) DEFAULT NULL,
  `id_user` int(10) DEFAULT NULL,
  `meta_title` varchar(155) COLLATE latin1_general_ci NOT NULL,
  `meta_keywords` varchar(155) COLLATE latin1_general_ci NOT NULL,
  `meta_description` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `title` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `seo_url` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `description` text COLLATE latin1_general_ci,
  `image` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `favourites` int(11) NOT NULL DEFAULT '0',
  `views` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `r_seo_url`
--

CREATE TABLE `r_seo_url` (
  `id_seo_url` int(11) NOT NULL,
  `seo_url` varchar(150) COLLATE latin1_general_ci NOT NULL,
  `id_category` int(11) DEFAULT '0',
  `id_post` int(11) DEFAULT '0',
  `id_page` int(11) DEFAULT '0',
  `id_user` int(11) DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `r_site_details`
--

CREATE TABLE `r_site_details` (
  `id` int(11) NOT NULL,
  `site_name` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `owner_email` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `email_from` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `replay_email` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `title` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `meta_description` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `meta_keywords` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `google_analytics_code` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `copyrights` varchar(255) COLLATE latin1_general_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `r_skill`
--

CREATE TABLE `r_skill` (
  `id_skill` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `status` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `r_subscribe`
--

CREATE TABLE `r_subscribe` (
  `id_email` int(11) NOT NULL,
  `email` varchar(255) COLLATE latin1_general_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `r_user`
--

CREATE TABLE `r_user` (
  `id_user` int(11) NOT NULL,
  `id_user_role` int(11) NOT NULL,
  `name` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `phone` varchar(99) COLLATE latin1_general_ci DEFAULT NULL,
  `department` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `email` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `password` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  `activate_link` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `skills` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `id_country` int(11) DEFAULT NULL,
  `image` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `meta_title` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `meta_keywords` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `meta_description` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `r_user_role`
--

CREATE TABLE `r_user_role` (
  `id_user_role` int(11) NOT NULL,
  `role` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `r_category`
--
ALTER TABLE `r_category`
  ADD PRIMARY KEY (`id_category`);

--
-- Indexes for table `r_comment`
--
ALTER TABLE `r_comment`
  ADD PRIMARY KEY (`id_comment`);

--
-- Indexes for table `r_country`
--
ALTER TABLE `r_country`
  ADD PRIMARY KEY (`id_country`);

--
-- Indexes for table `r_image`
--
ALTER TABLE `r_image`
  ADD PRIMARY KEY (`id_image`);

--
-- Indexes for table `r_message`
--
ALTER TABLE `r_message`
  ADD PRIMARY KEY (`id_message`);

--
-- Indexes for table `r_page`
--
ALTER TABLE `r_page`
  ADD PRIMARY KEY (`id_page`);

--
-- Indexes for table `r_post`
--
ALTER TABLE `r_post`
  ADD PRIMARY KEY (`id_post`);

--
-- Indexes for table `r_seo_url`
--
ALTER TABLE `r_seo_url`
  ADD PRIMARY KEY (`id_seo_url`),
  ADD UNIQUE KEY `seo_url` (`seo_url`);

--
-- Indexes for table `r_site_details`
--
ALTER TABLE `r_site_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `r_skill`
--
ALTER TABLE `r_skill`
  ADD PRIMARY KEY (`id_skill`);

--
-- Indexes for table `r_subscribe`
--
ALTER TABLE `r_subscribe`
  ADD PRIMARY KEY (`id_email`);

--
-- Indexes for table `r_user`
--
ALTER TABLE `r_user`
  ADD PRIMARY KEY (`id_user`),
  ADD KEY `meta_title` (`meta_title`);

--
-- Indexes for table `r_user_role`
--
ALTER TABLE `r_user_role`
  ADD PRIMARY KEY (`id_user_role`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `r_category`
--
ALTER TABLE `r_category`
  MODIFY `id_category` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `r_comment`
--
ALTER TABLE `r_comment`
  MODIFY `id_comment` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `r_country`
--
ALTER TABLE `r_country`
  MODIFY `id_country` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `r_image`
--
ALTER TABLE `r_image`
  MODIFY `id_image` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `r_message`
--
ALTER TABLE `r_message`
  MODIFY `id_message` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `r_page`
--
ALTER TABLE `r_page`
  MODIFY `id_page` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `r_post`
--
ALTER TABLE `r_post`
  MODIFY `id_post` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `r_seo_url`
--
ALTER TABLE `r_seo_url`
  MODIFY `id_seo_url` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `r_site_details`
--
ALTER TABLE `r_site_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `r_skill`
--
ALTER TABLE `r_skill`
  MODIFY `id_skill` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `r_subscribe`
--
ALTER TABLE `r_subscribe`
  MODIFY `id_email` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `r_user`
--
ALTER TABLE `r_user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `r_user_role`
--
ALTER TABLE `r_user_role`
  MODIFY `id_user_role` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
